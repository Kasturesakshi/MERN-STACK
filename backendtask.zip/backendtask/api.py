 from fastapi import FastAPI, Query, HTTPException
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import func
import requests
from datetime import datetime

# FastAPI app instance
app = FastAPI()

# Database setup
DATABASE_URL = "sqlite:///./products.db"  # SQLite for development
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
Base = declarative_base()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Database model
class ProductTransaction(Base):
    __tablename__ = "product_transactions"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(String)
    price = Column(Float)
    date_of_sale = Column(Date)
    is_sold = Column(Boolean)
    category = Column(String)

    def as_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "price": self.price,
            "date_of_sale": self.date_of_sale.strftime("%Y-%m-%d"),
            "is_sold": self.is_sold,
            "category": self.category,
        }


# Create tables
Base.metadata.create_all(bind=engine)

# Initialize the database with data from third-party API
@app.post("/initialize-database")
def initialize_database():
    response = requests.get("https://s3.amazonaws.com/roxiler.com/product_transaction.json")
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail="Failed to fetch data from third-party API")

    data = response.json()
    with SessionLocal() as db:
        db.query(ProductTransaction).delete()  # Clear existing data
        for item in data:
            transaction = ProductTransaction(
                id=item["id"],
                title=item["title"],
                description=item["description"],
                price=item["price"],
                date_of_sale=datetime.strptime(item["dateOfSale"], "%Y-%m-%d"),
                is_sold=item["sold"],
                category=item["category"],
            )
            db.add(transaction)
        db.commit()
    return {"message": "Database initialized successfully"}

# List transactions with search and pagination
@app.get("/transactions")
def list_transactions(
    month: str,
    search: str = "",
    page: int = 1,
    per_page: int = 10,
):
    with SessionLocal() as db:
        query = db.query(ProductTransaction).filter(func.strftime("%m", ProductTransaction.date_of_sale) == month)
        if search:
            search_pattern = f"%{search}%"
            query = query.filter(
                ProductTransaction.title.like(search_pattern) |
                ProductTransaction.description.like(search_pattern) |
                ProductTransaction.price == float(search) if search.isdigit() else False
            )
        total = query.count()
        transactions = query.offset((page - 1) * per_page).limit(per_page).all()
        return {"total": total, "transactions": [transaction.as_dict() for transaction in transactions]}

# Statistics API
@app.get("/statistics")
def get_statistics(month: str):
    with SessionLocal() as db:
        transactions = db.query(ProductTransaction).filter(func.strftime("%m", ProductTransaction.date_of_sale) == month).all()
        total_sales_amount = sum([t.price for t in transactions if t.is_sold])
        total_sold_items = sum([1 for t in transactions if t.is_sold])
        total_not_sold_items = sum([1 for t in transactions if not t.is_sold])
        return {
            "total_sales_amount": total_sales_amount,
            "total_sold_items": total_sold_items,
            "total_not_sold_items": total_not_sold_items,
        }

# Bar chart API
@app.get("/bar-chart")
def bar_chart(month: str):
    with SessionLocal() as db:
        transactions = db.query(ProductTransaction).filter(func.strftime("%m", ProductTransaction.date_of_sale) == month).all()
        price_ranges = {
            "0-100": 0, "101-200": 0, "201-300": 0, "301-400": 0,
            "401-500": 0, "501-600": 0, "601-700": 0, "701-800": 0,
            "801-900": 0, "901-above": 0,
        }
        for t in transactions:
            if t.price <= 100:
                price_ranges["0-100"] += 1
            elif t.price <= 200:
                price_ranges["101-200"] += 1
            elif t.price <= 300:
                price_ranges["201-300"] += 1
            elif t.price <= 400:
                price_ranges["301-400"] += 1
            elif t.price <= 500:
                price_ranges["401-500"] += 1
            elif t.price <= 600:
                price_ranges["501-600"] += 1
            elif t.price <= 700:
                price_ranges["601-700"] += 1
            elif t.price <= 800:
                price_ranges["701-800"] += 1
            elif t.price <= 900:
                price_ranges["801-900"] += 1
            else:
                price_ranges["901-above"] += 1
        return price_ranges

# Pie chart API
@app.get("/pie-chart")
def pie_chart(month: str):
    with SessionLocal() as db:
        transactions = db.query(ProductTransaction).filter(func.strftime("%m", ProductTransaction.date_of_sale) == month).all()
        categories = {}
        for t in transactions:
            categories[t.category] = categories.get(t.category, 0) + 1
        return categories

# Combined data API
@app.get("/combined-data")
def combined_data(month: str):
    stats = get_statistics(month)
    bar = bar_chart(month)
    pie = pie_chart(month)
    return {"statistics": stats, "bar_chart": bar, "pie_chart": pie}
